"""
Task 1: Loading and Inspecting the Datasets
Week 1 -- Data Foundation and Exploration

Loads the three generated CSVs and prints structure/content summaries.
Run this after generate_dataset.py.
"""
import pandas as pd

utilities = pd.read_csv('utilities.csv')
substations = pd.read_csv('substations.csv')
lines = pd.read_csv('lines.csv')

print("=" * 70)
print("UTILITIES")
print("=" * 70)
print(utilities.info())
print("\nFirst 5 rows:")
print(utilities.head())

print("\n" + "=" * 70)
print("SUBSTATIONS")
print("=" * 70)
print(substations.info())
print("\nFirst 5 rows:")
print(substations.head())

print("\n" + "=" * 70)
print("LINES")
print("=" * 70)
print(lines.info())
print("\nFirst 5 rows:")
print(lines.head())
