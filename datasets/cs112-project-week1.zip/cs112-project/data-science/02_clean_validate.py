"""
Task 2/1.1/1.3: Cleaning, Validation and Relationship Mapping
Week 1 -- Data Foundation and Exploration

Even though the generator produces clean data, this script demonstrates the
checks a real grid asset register would need: missing values, duplicates,
type consistency, coordinate plausibility, and referential integrity between
substations.csv and lines.csv. Findings feed data_cleaning_report.md.
"""
import numpy as np
import pandas as pd

utilities = pd.read_csv('utilities.csv')
substations = pd.read_csv('substations.csv')
lines = pd.read_csv('lines.csv')

report_lines = []

def log(msg=""):
    print(msg)
    report_lines.append(msg)

log("=" * 70)
log("1. MISSING VALUES")
log("=" * 70)
for name, df in [("utilities", utilities), ("substations", substations), ("lines", lines)]:
    n_missing = df.isnull().sum().sum()
    log(f"{name}: {n_missing} missing values across all columns")
    if n_missing:
        log(str(df.isnull().sum()[df.isnull().sum() > 0]))

log("\n" + "=" * 70)
log("2. DUPLICATE ROWS")
log("=" * 70)
for name, df in [("utilities", utilities), ("substations", substations), ("lines", lines)]:
    log(f"{name}: {df.duplicated().sum()} fully duplicate rows")

log(f"\nDuplicate Substation IDs: {substations['Substation ID'].duplicated().sum()}")
log(f"Duplicate Utility IDs: {utilities['Utility ID'].duplicated().sum()}")
log(f"Duplicate Line IDs: {lines['Line ID'].duplicated().sum()}")

log("\n" + "=" * 70)
log("3. TYPE CONSISTENCY (coercing numeric columns)")
log("=" * 70)
numeric_checks = {
    'substations': ['Latitude', 'Longitude', 'Voltage (kV)', 'Capacity (MVA)', 'Commissioning Year'],
    'lines': ['Length (km)', 'Capacity (MVA)', 'Voltage (kV)'],
}
before_types = {c: substations[c].dtype for c in numeric_checks['substations']}
for col in numeric_checks['substations']:
    substations[col] = pd.to_numeric(substations[col], errors='coerce')
for col in numeric_checks['lines']:
    lines[col] = pd.to_numeric(lines[col], errors='coerce')
new_nulls_from_coercion = (substations[numeric_checks['substations']].isnull().sum().sum()
                           + lines[numeric_checks['lines']].isnull().sum().sum())
log(f"New NaNs introduced by numeric coercion: {new_nulls_from_coercion} "
    f"(0 confirms every value in these columns was already a clean number)")

log("\n" + "=" * 70)
log("4. REFERENTIAL INTEGRITY (lines -> substations, lines -> utilities)")
log("=" * 70)
valid_sub_ids = set(substations['Substation ID'])
valid_utility_ids = set(utilities['Utility ID'])
orphan_source = lines[~lines['Source Substation ID'].isin(valid_sub_ids)]
orphan_dest = lines[~lines['Destination Substation ID'].isin(valid_sub_ids)]
orphan_utility = lines[~lines['Utility ID'].isin(valid_utility_ids)]
log(f"Lines with an orphaned Source Substation ID: {len(orphan_source)}")
log(f"Lines with an orphaned Destination Substation ID: {len(orphan_dest)}")
log(f"Lines with an orphaned Utility ID: {len(orphan_utility)}")
self_loops = lines[lines['Source Substation ID'] == lines['Destination Substation ID']]
log(f"Self-loop lines (source == destination): {len(self_loops)}")

log("\n" + "=" * 70)
log("5. GEOGRAPHIC PLAUSIBILITY (West Africa bounding box, roughly lat 4-15N, lon -15-5)")
log("=" * 70)
lat_out = substations[(substations['Latitude'] < 4) | (substations['Latitude'] > 15)]
lon_out = substations[(substations['Longitude'] < -15) | (substations['Longitude'] > 5)]
log(f"Substations with Latitude outside plausible West-African range: {len(lat_out)}")
log(f"Substations with Longitude outside plausible West-African range: {len(lon_out)}")

log("\n" + "=" * 70)
log("6. CATEGORICAL LABEL CONSISTENCY")
log("=" * 70)
log(f"Substation Status values: {sorted(substations['Status'].unique())}")
log(f"Substation Type values: {sorted(substations['Type'].unique())}")
log(f"Line Status values: {sorted(lines['Status'].unique())}")
log(f"Line Type values: {sorted(lines['Line Type'].unique())}")
log(f"Utility Type values: {sorted(utilities['Type'].unique())}")

log("\n" + "=" * 70)
log("7. KNOWN DATA-QUALITY QUIRK WORTH FLAGGING")
log("=" * 70)
cross_border_names = {"Bolgatanga Interconnection", "Elubo Border Station", "Aflao Border Station",
                       "Lome Transmission Hub", "Cotonou Transmission Hub",
                       "Abidjan Transmission Hub", "Bobo-Dioulasso Hub", "Conakry Transmission Hub"}
cb = substations[substations['Short Name'].isin(cross_border_names)]
log("Cross-border nodes have Region set to a descriptive phrase (e.g. 'Burkina Faso border')")
log("and Country set to only the FIRST WORD of that phrase, which truncates multi-word")
log("country names. Example rows:")
log(str(cb[['Short Name', 'Region', 'Country']].to_string(index=False)))
log("\n-> 'Cote d'Ivoire border' becomes Country='Cote' and 'Burkina Faso border' becomes")
log("   Country='Burkina'. This is a genuine label-standardisation issue to document and")
log("   fix (e.g. map Region -> a clean Country via a lookup) rather than an actual gap,")
log("   and is exactly the kind of inconsistency Task 1.1 asks you to demonstrate you can spot.")

log("\n" + "=" * 70)
log("SUMMARY")
log("=" * 70)
log(f"utilities.csv   : {len(utilities)} rows, {utilities.isnull().sum().sum()} missing, "
    f"{utilities.duplicated().sum()} duplicates")
log(f"substations.csv : {len(substations)} rows, {substations.isnull().sum().sum()} missing, "
    f"{substations.duplicated().sum()} duplicates")
log(f"lines.csv       : {len(lines)} rows, {lines.isnull().sum().sum()} missing, "
    f"{lines.duplicated().sum()} duplicates")
log(f"Orphaned FK references in lines.csv: {len(orphan_source) + len(orphan_dest) + len(orphan_utility)}")
log("Verdict: dataset is internally consistent. The one real cleaning task is the")
log("Region/Country truncation on cross-border nodes flagged in section 7 above.")

with open('validation_output.txt', 'w') as f:
    f.write("\n".join(report_lines))
