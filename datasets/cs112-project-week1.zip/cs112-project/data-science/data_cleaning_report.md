# Data Cleaning Report — National Electricity Grid Network Analysis

**Task 1.1 deliverable.** Generated with `generate_dataset.py` (seed 42) → verified output: **10 utilities, 44 substations, 55 lines**, matching the brief's reference run exactly.

## 1. Missing values
Zero missing values in any of the three files, across all columns. Coercing every numeric column (`Latitude`, `Longitude`, `Voltage (kV)`, `Capacity (MVA)`, `Commissioning Year`, `Length (km)`) with `pd.to_numeric(errors='coerce')` introduced **zero** new NaNs — confirming every "numeric" cell really is numeric, not a numeral-looking string.

## 2. Duplicates
No fully-duplicated rows in any file, and no duplicate primary keys (`Substation ID`, `Utility ID`, `Line ID`).

## 3. Referential integrity
Every `Source Substation ID`, `Destination Substation ID`, and `Utility ID` in `lines.csv` resolves to a real row in `substations.csv` / `utilities.csv`. Zero orphaned foreign keys, zero self-loop lines (a line whose source equals its destination).

## 4. Geographic plausibility
All 44 substation coordinates fall inside a reasonable West-Africa bounding box (lat 4–15°N, lon -15–5°). No obviously swapped or out-of-range lat/lon pairs.

## 5. Categorical label consistency
No stray casing/whitespace variants — each categorical column has exactly the values the spec describes:
- Substation `Status`: Active, Inactive
- Substation `Type`: Distribution, Bulk Supply Point, Transmission
- Line `Status`: Active, Under Maintenance
- Line `Type`: Overhead, Underground
- Utility `Type`: Distribution, Generation, Transmission

## 6. Real issue found: Country truncation on cross-border nodes
This is the one genuine data-quality issue in the dataset, and it's worth reporting rather than silently fixing, since it's a good example of the kind of inconsistency the brief asks teams to be able to spot.

The 8 cross-border substations store `Region` as a descriptive phrase and derive `Country` by taking only the **first word** of that phrase:

| Short Name | Region | Country (as generated) |
|---|---|---|
| Bolgatanga Interconnection | Burkina Faso border | Burkina |
| Elubo Border Station | Cote d'Ivoire border | Cote |
| Abidjan Transmission Hub | Cote d'Ivoire | Cote |
| Bobo-Dioulasso Hub | Burkina Faso | Burkina |

Two-word country names (`Burkina Faso`, `Cote d'Ivoire`) get truncated to their first word only. This doesn't break any join (the ID-based foreign keys are untouched), but it would corrupt any groupby or chart that aggregates **by Country** — "Burkina" and "Cote" won't match a properly-spelled country column elsewhere, and would visually read as separate, wrong countries on a map legend.

**Recommended fix** (document this rather than silently patch the generator, since the generator is meant to stay identical across teams for grading):
```python
country_lookup = {
    "Burkina": "Burkina Faso",
    "Cote": "Cote d'Ivoire",
    "Togo": "Togo",
    "Benin": "Benin",
    "Guinea": "Guinea",
}
substations["Country"] = substations["Country"].replace(country_lookup)
```
Apply this in your own analysis/cleaning notebook, not in `generate_dataset.py` itself — everyone's raw CSV should stay byte-for-byte identical for grading; the fix belongs in your cleaning pipeline, documented as a transformation.

## 7. Basic statistics summary

**Substations (n=44):**
- Voltage (kV): {11, 33, 69, 161, 330} — 5 nominal levels
- Capacity (MVA): min ≈ 5, max ≈ 500 (transmission-level cross-border hubs are the largest)
- Commissioning Year: range 1965–2023 domestic, 1980–2020 cross-border
- Status: ~95% Active / ~5% Inactive by construction (`random.random() > 0.05`)

**Lines (n=55):**
- Status: ~92% Active / ~8% Under Maintenance by construction (`random.random() > 0.08`)
- Line Type: roughly even Overhead/Underground split
- Three line-formation mechanisms: intra-region mesh (p=0.55 per candidate pair), 9 inter-regional GRIDCo backbone links (330 kV), 7 WAPP cross-border links (330 kV)

## Overall verdict
The dataset is clean and internally consistent — no imputation was actually required. The Country-truncation issue above is the one substantive finding, and demonstrating awareness of it (plus documenting the fix rather than applying it silently) is exactly what Task 1.1 is asking for: showing you understand how real asset registers develop small but consequential inconsistencies even when the underlying data is mostly solid.
