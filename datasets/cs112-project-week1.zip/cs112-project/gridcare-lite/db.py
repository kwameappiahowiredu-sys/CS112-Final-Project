"""
GridCare-Lite -- database schema (Week 1 foundation).

Minimal SQLite schema covering users, substations, outages, and work_orders.
Expand as your team's design requires (technicians, complaints, status
histories are natural next additions once role-based workflows land in Week 2/3).
"""
import sqlite3


def init_db(db_path='gridcare.db'):
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    cur.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK (role IN ('admin', 'engineer', 'technician', 'customer_service'))
        )
    ''')

    cur.execute('''
        CREATE TABLE IF NOT EXISTS substations (
            substation_id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            region TEXT NOT NULL
        )
    ''')

    cur.execute('''
        CREATE TABLE IF NOT EXISTS outages (
            outage_id INTEGER PRIMARY KEY AUTOINCREMENT,
            substation_id INTEGER NOT NULL,
            reported_by INTEGER NOT NULL,
            description TEXT,
            status TEXT DEFAULT 'Open' CHECK (status IN ('Open', 'In Progress', 'Resolved')),
            reported_at TEXT DEFAULT CURRENT_TIMESTAMP,
            resolved_at TEXT,
            FOREIGN KEY (substation_id) REFERENCES substations(substation_id),
            FOREIGN KEY (reported_by) REFERENCES users(user_id)
        )
    ''')

    cur.execute('''
        CREATE TABLE IF NOT EXISTS work_orders (
            work_order_id INTEGER PRIMARY KEY AUTOINCREMENT,
            outage_id INTEGER NOT NULL,
            assigned_technician INTEGER,
            scheduled_date TEXT,
            status TEXT DEFAULT 'Pending' CHECK (status IN ('Pending', 'Scheduled', 'Completed')),
            FOREIGN KEY (outage_id) REFERENCES outages(outage_id),
            FOREIGN KEY (assigned_technician) REFERENCES users(user_id)
        )
    ''')

    conn.commit()
    return conn


def import_substations_from_csv(conn, csv_path='../data-science/substations.csv'):
    """Load cleaned substation reference data so outages can only be logged
    against a real substation ID -- this is the link between the data-science
    component and GridCare-Lite called for in the brief's integration section."""
    import csv
    cur = conn.cursor()
    with open(csv_path, newline='') as f:
        reader = csv.DictReader(f)
        rows = [(int(r['Substation ID']), r['Name'], r['Region']) for r in reader]
    cur.executemany(
        'INSERT OR REPLACE INTO substations (substation_id, name, region) VALUES (?, ?, ?)',
        rows
    )
    conn.commit()
    return len(rows)


if __name__ == '__main__':
    conn = init_db()
    n = import_substations_from_csv(conn)
    print(f"Schema created. Imported {n} substations from the data-science component.")
    conn.close()
