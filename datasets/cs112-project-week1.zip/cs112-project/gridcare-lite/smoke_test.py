"""
Headless smoke test for GridCare-Lite's database layer.
No display is available in this environment, so this exercises everything
the GUI would touch *except* the actual tk.mainloop() window -- schema
creation, substation import from the data-science CSV, and a full
outage -> work_order round trip.
"""
import os
import sqlite3

from db import init_db, import_substations_from_csv

TEST_DB = 'gridcare_smoketest.db'
if os.path.exists(TEST_DB):
    os.remove(TEST_DB)

conn = init_db(TEST_DB)
print("[OK] init_db() created the schema")

tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
print(f"[OK] Tables present: {sorted(t[0] for t in tables)}")

n = import_substations_from_csv(conn)
print(f"[OK] Imported {n} substations from ../data-science/substations.csv")

cur = conn.cursor()
cur.execute("INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
            ('e.owusu', 'placeholder_hash', 'engineer'))
user_id = cur.lastrowid
print(f"[OK] Inserted test user, user_id={user_id}")

# Log an outage against a real substation ID pulled from the imported reference data
sub_id = conn.execute("SELECT substation_id FROM substations LIMIT 1").fetchone()[0]
cur.execute(
    "INSERT INTO outages (substation_id, reported_by, description) VALUES (?, ?, ?)",
    (sub_id, user_id, 'Test fault: voltage drop reported by field crew')
)
outage_id = cur.lastrowid
print(f"[OK] Logged outage_id={outage_id} against substation_id={sub_id}")

cur.execute(
    "INSERT INTO work_orders (outage_id, assigned_technician, scheduled_date, status) VALUES (?, ?, ?, ?)",
    (outage_id, user_id, '2026-08-03', 'Scheduled')
)
conn.commit()
print("[OK] Created linked work order")

# Round-trip: does an outage-to-substation join actually resolve?
row = conn.execute('''
    SELECT o.outage_id, o.description, s.name, s.region, w.status
    FROM outages o
    JOIN substations s ON o.substation_id = s.substation_id
    JOIN work_orders w ON w.outage_id = o.outage_id
    WHERE o.outage_id = ?
''', (outage_id,)).fetchone()
print(f"[OK] Round-trip join result: {row}")

conn.close()
os.remove(TEST_DB)
print("\nAll GridCare-Lite database checks passed.")
