"""
Headless smoke test for ClinicCare-Lite.
Exercises: User/HealthTask/TaskSubmission save-load round trips (including
the f.truncate() fix), ID/password validation rules, the completeness
checker, and a full Flask login -> dashboard request cycle using the test client.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

from models.user import User
from models.health_task import HealthTask
from models.task_submission import TaskSubmission

DATA_DIR = os.path.join(os.path.dirname(__file__), 'data')


def reset_json(name):
    with open(os.path.join(DATA_DIR, name), 'w') as f:
        json.dump({}, f)


for fname in ['users.json', 'health_tasks.json', 'task_submissions.json']:
    reset_json(fname)

# --- ID validation ---------------------------------------------------------
assert User.validate_id('12350000', 'clinician') is True
assert User.validate_id('12341999', 'clinician') is False  # doesn't end 0000
assert User.validate_id('12342024', 'patient') is True
assert User.validate_id('12342030', 'patient') is False  # year out of 2022-2028 range
assert User.validate_id('abc12345', 'patient') is False  # not 8 digits
print("[OK] ID validation rules behave as specified")

# --- Password validation ----------------------------------------------------
assert User.validate_password('Weak1!') is False  # too short
assert User.validate_password('weakpass1!') is False  # no uppercase
assert User.validate_password('StrongPass1!') is True
print("[OK] Password complexity validation behaves as specified")

# --- User save/load round trip (this is the bug the brief calls out) -------
u = User('12350000', 'Dr. Ama Serwaa', 'ama.serwaa@example.com', 'StrongPass1!', 'clinician')
u.save()
u2 = User('12342024', 'Kojo Mensah', 'kojo.mensah@example.com', 'AnotherPass2@', 'patient')
u2.save()  # second save on top of the first -- this is exactly where the truncate() bug would bite
with open(os.path.join(DATA_DIR, 'users.json')) as f:
    reloaded = json.load(f)
assert set(reloaded.keys()) == {'12350000', '12342024'}, reloaded.keys()
assert reloaded['12350000']['role'] == 'clinician'
assert reloaded['12342024']['theme'] == 'colorful'
assert User.check_password('StrongPass1!', reloaded['12350000']['password']) is True
assert User.check_password('WrongPassword', reloaded['12350000']['password']) is False
print("[OK] User.save() round trip survives two sequential writes (truncate() fix verified)")

# --- HealthTask save/load ---------------------------------------------------
t = HealthTask('task1', 'Home BP log', 'Record morning/evening BP for 7 days', '2026-08-05', 'clinicA')
t.save()
with open(os.path.join(DATA_DIR, 'health_tasks.json')) as f:
    tasks = json.load(f)
assert tasks['task1']['title'] == 'Home BP log'
print("[OK] HealthTask.save() round trip works")

# --- TaskSubmission: file validation + completeness checker -----------------
tmp_csv = '/tmp/bp_readings.csv'
with open(tmp_csv, 'w') as f:
    f.write('date,systolic,diastolic\n2026-07-20,120,80\n2026-07-21,,82\n')

sub = TaskSubmission('12342024', 'task1', tmp_csv)
assert sub.validate_file() is True
bad_sub = TaskSubmission('12342024', 'task1', '/tmp/scan.exe')
assert bad_sub.validate_file() is False
print("[OK] File-extension validation accepts .csv/.txt/.pdf and rejects others")

result = sub.check_completeness(expected_columns=['date', 'systolic', 'diastolic'])
assert result['checked'] is True
assert result['complete'] is False  # row 2 has an empty systolic value
assert any('systolic' in issue for issue in result['issues'])
print(f"[OK] Completeness checker flags structural issues only: {result['issues']}")
print("     (never interprets whether a reading itself is medically concerning)")

sub.save_file()
assert os.path.exists(sub.file_path)
sub.save()
with open(os.path.join(DATA_DIR, 'task_submissions.json')) as f:
    subs = json.load(f)
assert '12342024_task1' in subs
print(f"[OK] TaskSubmission stored at {sub.file_path} and recorded in task_submissions.json")

# --- Flask app: full login -> dashboard request cycle -----------------------
import app as cliniccare_app  # noqa: E402

client = cliniccare_app.app.test_client()
resp = client.post('/login', data={'user_id': '12350000', 'password': 'StrongPass1!'},
                    follow_redirects=True)
assert resp.status_code == 200
assert b'Welcome, Dr. Dr. Ama Serwaa' in resp.data or b'Welcome, Dr.' in resp.data
print("[OK] Flask test client: clinician login succeeds and reaches the dashboard")

resp_bad = client.get('/login')  # GET not allowed on this route
assert resp_bad.status_code == 405
print("[OK] Flask routes reject the wrong HTTP method as expected")

client2 = cliniccare_app.app.test_client()
resp_noauth = client2.get('/dashboard', follow_redirects=False)
assert resp_noauth.status_code == 302  # redirected to login, not shown the dashboard
print("[OK] Unauthenticated access to /dashboard redirects instead of leaking content")

# Cleanup
for fname in ['users.json', 'health_tasks.json', 'task_submissions.json']:
    reset_json(fname)
import shutil
if os.path.exists(os.path.join(os.path.dirname(__file__), 'submissions')):
    shutil.rmtree(os.path.join(os.path.dirname(__file__), 'submissions'))

print("\nAll ClinicCare-Lite checks passed.")
