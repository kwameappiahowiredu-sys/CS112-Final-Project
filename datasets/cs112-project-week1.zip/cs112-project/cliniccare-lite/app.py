"""
ClinicCare-Lite -- Flask application (Week 1 executable prototype).

Administrative and communication system only -- it must never diagnose,
interpret symptoms, or recommend treatment. See docs/cliniccare-ethical-boundary.md.
"""
import json
import os

import bcrypt
from flask import Flask, redirect, render_template, request, session, url_for

DATA_DIR = os.path.join(os.path.dirname(__file__), 'data')

app = Flask(__name__)
app.secret_key = os.environ.get('CLINICCARE_SECRET_KEY', 'dev-only-change-me')


def load_users():
    with open(os.path.join(DATA_DIR, 'users.json')) as f:
        return json.load(f)


@app.route('/')
def index():
    return render_template('login.html')


@app.route('/login', methods=['POST'])
def login():
    user_id = request.form['user_id']
    password = request.form['password']
    users = load_users()
    if user_id in users and bcrypt.checkpw(
            password.encode('utf-8'), users[user_id]['password'].encode('utf-8')):
        session['user_id'] = user_id
        session['role'] = users[user_id]['role']
        return redirect(url_for('dashboard'))
    return render_template('login.html', error='Invalid credentials')


@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    role = session['role']
    users = load_users()
    name = users[session['user_id']]['name']
    if role == 'clinician':
        return render_template('clinician_dashboard.html', name=name)
    return render_template('patient_dashboard.html', name=name)


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))


# Additional routes for health-task creation, submission, review, messaging, etc.
# land in Week 2/3 alongside the patient- and clinician-workflow modules.

if __name__ == '__main__':
    app.run(debug=True)
