"""ClinicCare-Lite -- email notifications via SMTP.
Credentials must come from environment variables, never hard-coded (see
docs/coding-standards.md and the Member 1 security checklist in the brief)."""
import os
import smtplib
from email.mime.text import MIMEText


def send_email(recipient_email, subject, body,
                sender_email=None, sender_password=None,
                smtp_host='smtp.gmail.com', smtp_port=587):
    sender_email = sender_email or os.environ.get('CLINICCARE_SMTP_USER')
    sender_password = sender_password or os.environ.get('CLINICCARE_SMTP_PASSWORD')
    if not sender_email or not sender_password:
        raise RuntimeError(
            'Set CLINICCARE_SMTP_USER / CLINICCARE_SMTP_PASSWORD env vars '
            '(use a sandbox/test account for demos, never real credentials in source).'
        )
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = sender_email
    msg['To'] = recipient_email
    with smtplib.SMTP(smtp_host, smtp_port) as server:
        server.starttls()
        server.login(sender_email, sender_password)
        server.send_message(msg)


def notify_submission_received(clinician_email, patient_name, task_title):
    body = f"{patient_name} submitted '{task_title}'. Log in to ClinicCare-Lite to review it."
    send_email(clinician_email, 'New submission awaiting review', body)


def notify_review_outcome(patient_email, task_title, outcome, notes=None):
    body = f"Your submission for '{task_title}' has been reviewed. Outcome: {outcome}."
    if notes:
        body += f"\n\nClinician notes: {notes}"
    body += "\n\nThis is an automated administrative notice, not a diagnosis."
    send_email(patient_email, f"Review update: {task_title}", body)
