"""ClinicCare-Lite -- TaskSubmission model. Administrative only: file handling
and structural validation, never interpretation of the submitted health data."""
import json
import os
import shutil
from datetime import datetime

DATA_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'task_submissions.json')
SUBMISSIONS_ROOT = os.path.join(os.path.dirname(__file__), '..', 'submissions')

ALLOWED_EXTENSIONS = ('.txt', '.csv', '.pdf')


class TaskSubmission:
    def __init__(self, patient_id, task_id, file_path):
        self.patient_id = patient_id
        self.task_id = task_id
        self.file_path = file_path
        self.timestamp = datetime.now().isoformat()
        self.review_status = 'Pending'  # Pending / Reviewed - Normal / Needs Follow-up / Escalated
        self.notes = None

    def validate_file(self):
        return self.file_path.lower().endswith(ALLOWED_EXTENSIONS)

    def save_file(self):
        if not self.validate_file():
            raise ValueError(f'Only {ALLOWED_EXTENSIONS} files are allowed')
        ext = os.path.splitext(self.file_path)[1]
        dest_dir = os.path.join(SUBMISSIONS_ROOT, str(self.patient_id))
        dest_path = os.path.join(dest_dir, f'{self.task_id}{ext}')
        os.makedirs(dest_dir, exist_ok=True)
        # Guard against path traversal in patient_id/task_id before this ever reaches a real request
        if os.path.commonpath([os.path.abspath(dest_path), os.path.abspath(SUBMISSIONS_ROOT)]) \
                != os.path.abspath(SUBMISSIONS_ROOT):
            raise ValueError('Invalid submission path')
        shutil.copy(self.file_path, dest_path)
        self.file_path = dest_path

    def check_completeness(self, expected_columns=None):
        """Purely structural check -- are the expected fields present and non-empty?
        Never interprets the clinical meaning of a value (see project scope boundary)."""
        if not self.file_path.lower().endswith('.csv') or expected_columns is None:
            return {'checked': False, 'reason': 'Completeness check only applies to .csv with a schema'}
        import csv
        issues = []
        with open(self.file_path, newline='') as f:
            reader = csv.DictReader(f)
            fieldnames = reader.fieldnames or []
            missing_cols = [c for c in expected_columns if c not in fieldnames]
            if missing_cols:
                issues.append(f"Missing column(s): {', '.join(missing_cols)}")
            for i, row in enumerate(reader, start=1):
                for col in expected_columns:
                    if col in row and not row[col].strip():
                        issues.append(f"Row {i}: '{col}' is empty")
        return {'checked': True, 'issues': issues, 'complete': len(issues) == 0}

    def save(self, path=DATA_PATH):
        with open(path, 'r+') as f:
            data = json.load(f)
            data[f'{self.patient_id}_{self.task_id}'] = {
                'patient_id': self.patient_id,
                'task_id': self.task_id,
                'file_path': self.file_path,
                'timestamp': self.timestamp,
                'review_status': self.review_status,
                'notes': self.notes,
            }
            f.seek(0)
            f.truncate()
            json.dump(data, f, indent=4)
