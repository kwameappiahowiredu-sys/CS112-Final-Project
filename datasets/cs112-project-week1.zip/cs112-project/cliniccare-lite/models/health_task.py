"""ClinicCare-Lite -- HealthTask model."""
import json
import os

DATA_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'health_tasks.json')


class HealthTask:
    def __init__(self, task_id, title, description, due_date, clinic_id):
        self.task_id = task_id
        self.title = title
        self.description = description
        self.due_date = due_date
        self.clinic_id = clinic_id

    def save(self, path=DATA_PATH):
        with open(path, 'r+') as f:
            data = json.load(f)
            data[self.task_id] = {
                'title': self.title,
                'description': self.description,
                'due_date': self.due_date,
                'clinic_id': self.clinic_id,
            }
            f.seek(0)
            f.truncate()
            json.dump(data, f, indent=4)
