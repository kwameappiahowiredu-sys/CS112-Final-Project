# Coding & Documentation Standards

Agreed once in Week 1 so nobody's code review turns into a style argument in Week 3.

## Python style
- **PEP 8**, 4-space indentation, `snake_case` for functions/variables, `PascalCase` for classes.
- Every function that isn't trivially self-explanatory gets a one-line docstring describing *what* it does and *why*, not a restatement of the code.
- No bare `except:` — catch specific exceptions (`sqlite3.IntegrityError`, `json.JSONDecodeError`, `ValueError`, etc.) so failures are diagnosable instead of silently swallowed.
- Secrets (SMTP credentials, `app.secret_key`, DB paths in production) come from environment variables, never hard-coded — see `utils/email_handler.py` for the pattern.

## Git / GitHub
- Branch names: `feature/<short-description>` (e.g. `feature/outage-work-orders`, `feature/patient-dashboard`).
- Commit messages: imperative mood, describe the *change* — `Add clinician ID validation`, not `updates`.
- No direct pushes to `main`. Every feature branch merges via a pull request with at least one reviewer.
- Before opening a PR: run the relevant smoke test / test file locally and confirm it passes.

## Data science component
- Every notebook/script cell that transforms data states *what* changed and *why* (e.g. "coerced Latitude/Longitude to numeric; 0 new NaNs introduced").
- Save intermediate outputs (`merged_lines.csv`, cleaned CSVs) rather than only printing to console — Week 3/4 dashboard work depends on being able to reload them.
- Any claim about "critical" substations or reliability must be labelled a **structural/graph-based proxy**, not an operational or electrical-engineering finding (see the brief's own caution on this point).

## GridCare-Lite / ClinicCare-Lite shared conventions
- Database access goes through a small set of functions per module (`db.py`, model `save()`/`load()` methods) — no ad-hoc SQL strings scattered across GUI callback code.
- Every user-facing action (login, submission, review, work-order assignment) has a success path *and* a handled failure path with a clear message — no silent failures, no raw stack traces shown to the user.
- Role checks happen server-side / in application logic, never just by hiding a button in the UI.

## Documentation
- Each component's README explains: what it does, how to run it, what's implemented vs. stubbed, and known limitations.
- Any deliberate scope exclusion (e.g. "no diagnostic features in ClinicCare-Lite," "no public leaderboard") gets one line in the README so a reviewer knows it's a decision, not an oversight.
