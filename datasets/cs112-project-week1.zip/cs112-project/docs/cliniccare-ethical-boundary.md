# ClinicCare-Lite — Ethical and Security Boundary Statement

Required Week 1 deliverable per the brief. This is meant to be agreed by the whole team *before* any feature work starts, since it constrains what gets built in Weeks 2–4.

## The hard boundary

ClinicCare-Lite is an **administrative and communication system**. It must never:
- Diagnose a patient
- Interpret the medical/clinical meaning of a symptom or reading
- Calculate disease risk or a health score
- Recommend treatment or medication
- Replace a clinician's professional judgement

Any automated feature is limited to **non-clinical, structural checks** — e.g. "is this required field present," "is this column populated," "does this file have the right extension." The system reports the *shape* of submitted data, never its *meaning*.

Concretely, the completeness checker may say:
> "The date field is missing."

It must never say:
> "Your blood-pressure reading is dangerous."

This is a **compulsory constraint**, not a stretch goal, and it applies throughout design, implementation, testing, documentation, and the final demonstration. Per the brief's grading rubric, a submission that crosses this line loses the relevant functionality/scope/ethics marks regardless of how polished the rest of the system is — this is worth remembering before anyone gets excited about adding a "smart" feature in Week 3.

## Privacy boundary

- A patient must never be able to view another patient's tasks, submissions, messages, or records.
- The private wellness-engagement tracker (Engagement Points) is visible **only to the patient who earned it** — no leaderboard, no cross-patient comparison, even anonymised. Ranking patients against each other risks exposing who is or isn't managing appointments/tasks well, which is exactly what confidentiality is meant to prevent.
- Clinician-facing analytics stay at the aggregate/operational level (no-show rate, completion rate, turnaround time) — never a view that exposes one patient's data to another patient or to an unauthorised user.
- The messaging channel must display a persistent, visible notice that it is **not monitored continuously and must not be used for emergencies**.

## Security boundary

- Passwords are hashed with bcrypt before storage — never stored or logged in plaintext.
- Session-based auth with role-based route protection: an unauthenticated request to a dashboard route redirects to login rather than leaking any page content (verified in `smoke_test.py`).
- Clinician access is scoped to their own clinic's patients, not every patient in the system.
- File uploads are restricted to `.txt`, `.csv`, `.pdf`; file paths are constructed defensively to prevent path traversal (see `TaskSubmission.save_file()`).
- SMTP and secret-key credentials come from environment variables, never hard-coded in source (see `utils/email_handler.py`).

## Why this belongs in Week 1, not Week 4

Every one of the four members' role descriptions in the brief references this boundary somewhere (Member 1's access-control work, Member 2's engagement tracker, Member 3's review-outcome categories instead of scores, Member 4's analytics scoping). Agreeing on it now means nobody builds a feature in Weeks 2–3 that has to be ripped out in Week 4 for crossing the line.
