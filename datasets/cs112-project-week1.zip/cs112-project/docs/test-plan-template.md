# Test Plan Template

Per the brief: "Every major test should document: Test objective, Input, Expected outcome, Actual outcome, Pass or fail status, Defect identified, Corrective action, Retest result." Copy the table below per subsystem as tests are written — don't wait until Week 4 to start filling this in.

## Test case table

| ID | Objective | Input | Expected Outcome | Actual Outcome | Pass/Fail | Defect | Corrective Action | Retest |
|----|-----------|-------|-------------------|-----------------|-----------|--------|--------------------|--------|
| DS-01 | Dataset generator reproduces reference counts | Run `generate_dataset.py` | 10 utilities, 44 substations, 55 lines | 10 / 44 / 55 | Pass | — | — | — |
| DS-02 | No orphaned foreign keys in lines.csv | Run `02_clean_validate.py` | 0 orphaned Source/Destination/Utility IDs | 0 / 0 / 0 | Pass | — | — | — |
| GC-01 | Schema creation | Run `db.init_db()` | 4 tables created (users, substations, outages, work_orders) | Confirmed via `sqlite_master` query | Pass | — | — | — |
| GC-02 | Outage → work order round trip | Insert outage + work order, join back | Row resolves with correct substation name/region | Confirmed | Pass | — | — | — |
| CC-01 | Clinician ID validation | `12350000` vs `12341999` | First valid, second invalid (doesn't end 0000) | Matches | Pass | — | — | — |
| CC-02 | Patient ID validation | `12342024` vs `12342030` | First valid, second invalid (year outside 2022–2028) | Matches | Pass | — | — | — |
| CC-03 | Password complexity | Weak vs. strong password strings | Weak rejected, strong accepted | Matches | Pass | — | — | — |
| CC-04 | JSON save/load round trip under repeated writes | Save two users sequentially, reload file | Both users present, no corruption | Matches | Pass | Historical: missing `f.truncate()` corrupts file on 2nd write | `f.truncate()` added after `f.seek(0)` | Pass |
| CC-05 | Completeness checker flags structural issues only | Submit CSV with one empty required cell | Reports "Row N: '<col>' is empty"; makes no clinical claim | Matches | Pass | — | — | — |
| CC-06 | Unauthenticated dashboard access | GET `/dashboard` with no session | Redirect (302) to login, not dashboard content | Matches | Pass | — | — | — |

## Categories to keep expanding (per the brief's testing sections)

**GridCare-Lite:** invalid login attempts, role-access violations, incorrect substation references, invalid status transitions, missing work-order details, duplicate outage records, technician-assignment errors, complaint-linking errors, database failures, report accuracy.

**ClinicCare-Lite:** invalid clinician/patient IDs, weak passwords, unauthorised record access, unsupported file types, oversized files, missing required fields, incorrect task ownership, duplicate submissions, messaging privacy, notification failure, patient-data exposure, diagnostic-scope violations.

**Data science:** data types, missing values, duplicate records, foreign-key relationships, merge results, graph construction, metric calculations, filters, reproducibility.
