# Week 1 Checklist — Requirements, Data Foundation and System Design

Per the brief's "Project Management Over Four to Five Weeks" section. Week 1 should end with **approved designs, a functioning repository, initial datasets, and small executable prototypes for both applications.**

| # | Task | Status | Where |
|---|------|--------|-------|
| 1 | Review the complete project requirements | ✅ Done | This analysis + the synthesis below |
| 2 | Assign member responsibilities | 🟡 **Team decision needed** | See "Role split" note below |
| 3 | Establish a shared GitHub repository | 🟡 **Check with Kwame** | Repo owner — confirm this structure matches / push it |
| 4 | Create a project board and task schedule | 🟡 **Team decision needed** | Use this checklist as a starting Week-1 board |
| 5 | Generate and inspect the electricity-grid datasets | ✅ Done | `data-science/generate_dataset.py` → verified 10/44/55 rows exactly matching the brief |
| 6 | Develop data-cleaning and validation plans | ✅ Done | `data-science/02_clean_validate.py` + `data_cleaning_report.md` |
| 7 | Produce preliminary application requirements | ✅ Done | GridCare-Lite + ClinicCare-Lite skeletons below implement the core entities from the spec |
| 8 | Draw use-case, class, architecture, and ERD diagrams | ✅ Started | `docs/erd-gridcare-lite.mermaid`, `docs/erd-cliniccare-lite.mermaid` — use-case/full class diagrams are a good Week 1 follow-up once roles are set |
| 9 | Decide on development frameworks | 🟡 **Team decision needed** | Skeletons built with Tkinter (GridCare-Lite) + Flask (ClinicCare-Lite) — the brief's suggested defaults; swap if your team prefers PyQt |
| 10 | Define coding and documentation standards | ✅ Draft ready | `docs/coding-standards.md` |
| 11 | Create initial test plans | ✅ Draft ready | `docs/test-plan-template.md` |
| 12 | Establish the ethical and security boundaries of ClinicCare-Lite | ✅ Done | `docs/cliniccare-ethical-boundary.md` |

## What's actually verified vs. what's a starting draft

**Verified by running the code (not just written):**
- Dataset generator reproduces the brief's exact reference counts (10 utilities / 44 substations / 55 lines)
- Data cleaning script found zero missing values, zero duplicates, zero orphaned foreign keys — plus one real, worth-documenting quirk (Country-field truncation on cross-border nodes, see the cleaning report)
- GridCare-Lite: schema creation, CSV import from the data-science component, and a full outage → work_order round-trip join all execute correctly
- ClinicCare-Lite: ID/password validation, the User/HealthTask/TaskSubmission save-load round trip (including the `f.truncate()` fix), the completeness checker, and a full Flask login → dashboard request cycle (plus auth-redirect protection) all pass

**Still needs your team's input (can't be decided for you):**
- Final role split across the 5 work-streams (grid data, GridCare-Lite, ClinicCare-Lite, viz/BI, testing/integration) — the brief explicitly allows you to diverge from its suggested 4-person templates
- Whether GridCare-Lite stays Tkinter or moves to PyQt
- Repository structure — this project folder is laid out ready to drop into Kwame's repo as-is (`data-science/`, `gridcare-lite/`, `cliniccare-lite/`, `docs/`) if that structure works for the team
